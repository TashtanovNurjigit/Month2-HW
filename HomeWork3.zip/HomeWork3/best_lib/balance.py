class Balance:
    pass
